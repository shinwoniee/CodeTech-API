package com.appdev.codetech;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodetechApplicationTests {

	@Test
	void contextLoads() {
	}

}
