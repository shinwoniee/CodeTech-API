package com.appdev.codetech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodetechApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodetechApplication.class, args);
		System.out.println("ok");
	}

}
